Product: T-Rex, October 2014

Designer: Marcell

Support:  http://forums.obrary.com/category/designs/t-rex

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Here's a 3D model that you can make on the laser cutter.  It has 29 pieces.